package com.example;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/add-item")
public class AddItemServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String item = request.getParameter("item");
        ArrayList<String> cart = getCartFromCookies(request.getCookies());

        if (item != null && !item.isEmpty()) {
            cart.add(item); // Allows duplicates; modify if you want to avoid duplicates
        }

        saveCartToCookies(cart, response);
        response.sendRedirect("view-cart");
    }

    private ArrayList<String> getCartFromCookies(Cookie[] cookies) {
        ArrayList<String> cart = new ArrayList<>();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("cart".equals(cookie.getName())) {
                    String[] items = cookie.getValue().split(",");
                    for (String item : items) {
                        if (!item.isEmpty()) { // Avoid adding empty items
                            cart.add(item);
                        }
                    }
                }
            }
        }
        return cart;
    }

    private void saveCartToCookies(ArrayList<String> cart, HttpServletResponse response) {
        StringBuilder cartValue = new StringBuilder();
        for (String item : cart) {
            if (cartValue.length() > 0) {
                cartValue.append(":");
            }
            cartValue.append(item);
        }
        // Log the cartValue for debugging
        System.out.println("Saving cart to cookie: " + cartValue.toString());

        Cookie cartCookie = new Cookie("cart", cartValue.toString());
        cartCookie.setMaxAge(60 * 60 * 24); // 1 day
        response.addCookie(cartCookie);
    }
}
